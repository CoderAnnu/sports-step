<div class="isb_sale_badge isb_image <?php echo esc_attr( $isb_class ); ?>">
	<img src="<?php echo esc_url( $isb_curr_set['image']); ?>" />
</div>