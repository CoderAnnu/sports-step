<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<?php do_action( 'product_loops_out_before' ); ?>

<?php do_action( 'product_loops_out_content' ); ?>

<?php do_action( 'product_loops_out_after' ); ?>