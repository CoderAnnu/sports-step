<div class="isb_sale_badge isb_special <?php echo esc_attr( $isb_class ); ?>">
	<span class="isb_special_text isb_color"><?php echo wp_kses_post( $isb_curr_set['special_text'] ); ?></span>
</div>