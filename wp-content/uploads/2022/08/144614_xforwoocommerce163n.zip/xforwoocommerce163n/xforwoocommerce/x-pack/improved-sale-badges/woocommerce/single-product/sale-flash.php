<?php

	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	do_action( 'xforwc_badges_product' );
