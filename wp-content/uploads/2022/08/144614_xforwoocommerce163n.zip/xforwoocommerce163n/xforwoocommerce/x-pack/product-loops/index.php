<?php
// Silence